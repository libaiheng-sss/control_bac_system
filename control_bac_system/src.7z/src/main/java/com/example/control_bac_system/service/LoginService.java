package com.example.control_bac_system.service;

public interface LoginService {

    String login(String username,String password);
}
